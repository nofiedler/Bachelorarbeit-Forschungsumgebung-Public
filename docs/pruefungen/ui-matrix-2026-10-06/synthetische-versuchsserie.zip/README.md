# Studienpaket

Dieses Archiv enthält Originale und den bestätigten Analysestand. CSV/Grafiken liegen unter `analysis/`. `runs.csv` enthält jede geplante Lauf-ID; leere Werte sind keine Nullen. Die grafischen und tabellarischen Daten sind beschreibend.

Import über Auswertung → Studienpakete. Nachrechnung braucht keinen API-Schlüssel und führt keinen Kandidatencode aus. Originale bleiben unverändert; passende installierte Analyseversion erforderlich. Die Aufnahme von Docker-Images und ein physischer externer Restore sind damit nicht nachgewiesen.
