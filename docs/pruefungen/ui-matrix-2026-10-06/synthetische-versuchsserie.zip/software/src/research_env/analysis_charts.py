"""Descriptive figures from the already computed, revision-bound study result."""
from fractions import Fraction
from .analysis import observed

COLORS={'K0':'#8c78c9','K1':'#2b9b87'}
MODULES={'BF':'Brute Force','SQL':'SQL Injection','UP':'File Upload'}


def figures(result):
    import matplotlib.pyplot as plt
    from .domain import MAIN_CELLS
    output=[]
    synthetic=result['data_origin']=='synthetic'
    def finish(fig,name,ids,unit):
        for ax in fig.axes:
            ax.spines[['top','right']].set_visible(False)
            ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
        footer=('SYNTHETISCHE TESTDATEN · ' if synthetic else '')+f'n={len(ids)} | Datenhash {result["data_hash"][:16]} | beschreibend, keine Konfidenzintervalle'
        fig.text(.02,.015,footer,fontsize=7,color='#656571')
        fig.tight_layout(rect=(0,.06,1,.97))
        output.append((name,fig,{'n':len(ids),'denominator_ids':ids,'unit':unit,'plot_data':'plot-data.json'}))
    def distribution(keys,title,name,metric='F',exploratory=False):
        fig,ax=plt.subplots(figsize=(10,5));ids=[];labels=[]
        for i,key in enumerate(keys):
            rows=[r for r in result['cells'] if r['cell_key']==key and (not exploratory or r['in_b_e'])]
            selected=[(r,observed(r['functional']['F'] if metric=='F' else r['static'][metric])) for r in rows]
            selected=[(r,v) for r,v in selected if v is not None]
            values=[float(v) for _,v in selected];cell=MAIN_CELLS[key]
            color=COLORS[cell.context];ids.extend(r['id'] for r,_ in selected)
            if len(values)>=2:
                box=ax.boxplot([values],positions=[i],widths=.48,patch_artist=True,showfliers=False,
                    medianprops={'color':'#292633'},whiskerprops={'color':'#aaa5b5'},capprops={'color':'#aaa5b5'})
                box['boxes'][0].set(facecolor=color,alpha=.20,edgecolor=color)
            if values:
                offsets=[((j%5)-2)*.045 for j in range(len(values))]
                ax.scatter([i+x for x in offsets],values,color=color,edgecolor='white',linewidth=.5,s=35,zorder=3)
            label=(MODULES[cell.module]+'\n'+cell.context) if key.startswith('C-') else {'E-AB':'P=A · V=B','E-BA':'P=B · V=A','E-BB':'P=B · V=B','E-P0R1':'Planner aus\nReview an','E-P1R0':'Planner an\nReview aus','E-P0R0':'Planner aus\nReview aus'}[key]
            labels.append(label+f'\nn={len(values)}/{len(rows)}')
        ax.set_xticks(range(len(keys)),labels,fontsize=8);ax.set_title(title,loc='left',fontweight='bold')
        ax.set_ylabel({'F':'Funktionaler Score F','D':'PHPStan-Diagnosen D','L':'PHP-Codezeilen L','S':'Diagnosen je 100 Codezeilen S'}[metric])
        if metric=='F':ax.set_ylim(-.05,1.05)
        if not ids:ax.text(.5,.5,'Noch keine gültigen Messwerte',transform=ax.transAxes,ha='center',color='#656571')
        finish(fig,name,ids,'ratio' if metric=='F' else metric)
    core=[f'C-{m}-{k}' for m in MODULES for k in (0,1)]
    distribution(core,'Kontextvergleich und Wiederholungsstreuung · UF1 / UF2 / UF6','kontext-verteilungen')
    distribution(['C-SQL-1','E-AB','E-BA','E-BB'],'Modellzuordnung im SQL/K1-Fokusfall · UF3','modellzuordnung',exploratory=True)
    distribution(['C-SQL-1','E-P0R1','E-P1R0','E-P0R0'],'Planner und Review im SQL/K1-Fokusfall · UF4','pipeline-varianten',exploratory=True)
    for metric in ('D','L','S'):distribution(core,'Statische Codequalität · '+metric,'statisch-'+metric,metric)
    fig,ax=plt.subplots(figsize=(9,4.5))
    vals=result['core']['values'];ids=result['B_C']
    if vals:
        indices=[block['index'] for block in result['blocks'] if block['in_B_C']]
        ax.plot(indices,[float(Fraction(v['value']))*100 for v in vals],marker='o',color='#6d42cf')
        ax.set_xticks([block['index'] for block in result['blocks']])
    else:ax.text(.5,.5,'Noch kein vollständiger Kernblock',transform=ax.transAxes,ha='center')
    ax.axhline(0,color='#89909e',linewidth=1);ax.set_xlabel('Vollständige Kernblöcke in Erhebungsreihenfolge');ax.set_ylabel('K1 − K0 (Prozentpunkte)');ax.set_title('Beobachtete Blockunterschiede · UF2 / UF6',loc='left',fontweight='bold')
    finish(fig,'blockunterschiede',ids,'percentage_points')
    for metric in ('pipeline_seconds','cost'):
        rows=[r for r in result['cells'] if r['cell_key'].startswith('C-')]
        currencies=sorted({r['resources']['costs']['currency'] for r in rows if r['resources'].get('costs') and r['resources']['costs']['currency']}) if metric=='cost' else [None]
        if not currencies:currencies=[None]
        for index,currency in enumerate(currencies):
            fig,ax=plt.subplots(figsize=(8,5));ids=[]
            for module,marker in zip(MODULES,('o','s','^')):
                for context in ('K0','K1'):
                    points=[]
                    for r in rows:
                        if r['cell_key']!=f'C-{module}-{context[-1]}':continue
                        f=observed(r['functional']['F']);resources=r['resources'];cost=resources.get('costs')
                        x=Fraction(cost['amount']) if metric=='cost' and cost and cost['status']=='known' and cost['currency']==currency else observed(resources.get(metric)) if metric!='cost' else None
                        if f is not None and x is not None:points.append((float(x),float(f)));ids.append(r['id'])
                    if points:ax.scatter([v[0] for v in points],[v[1] for v in points],color=COLORS[context],marker=marker,label=MODULES[module]+' · '+context,s=45,alpha=.8)
            ax.set_xlabel('Aktive Pipelinezeit (s)' if metric!='cost' else 'Bekannte Kosten ('+(currency or 'nicht erhoben')+')');ax.set_ylabel('Funktionaler Score F');ax.set_ylim(-.04,1.04)
            ax.set_title('Ergebnis und Ressourcen · UF5',loc='left',fontweight='bold')
            if ids:ax.legend(fontsize=8,loc='best')
            else:ax.text(.5,.5,'Noch keine vollständigen Wertepaarungen',transform=ax.transAxes,ha='center')
            finish(fig,'F-zeit' if metric!='cost' else 'F-kosten-'+str(index+1),ids,'s / ratio' if metric!='cost' else str(currency)+' / ratio')
    return output
