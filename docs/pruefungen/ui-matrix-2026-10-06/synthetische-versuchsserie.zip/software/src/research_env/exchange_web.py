"""Local archive transfer and isolated, key-free recalculation views."""
from contextlib import closing
import hashlib
import hmac
import json
import re
from uuid import UUID, uuid4
import zipfile

from fastapi import Request
from fastapi.responses import FileResponse, RedirectResponse, Response
from starlette.formparsers import MultiPartParser
from starlette.concurrency import run_in_threadpool

from . import exchange
from .analysis_store import source_binding
from .artifacts import atomic_file
from .domain import canonical
from .register import GateError, Register


def routes(app, settings, render, form):
    @app.get('/packages')
    def packages(request: Request):
        with closing(Register(settings, readonly=True)) as register:
            jobs = [dict(row) for row in register.connection.execute('SELECT * FROM exchange_job ORDER BY rowid DESC')]
        imports = []
        for path in sorted((settings.staging / 'imports').glob('*.zip')):
            with zipfile.ZipFile(path) as archive:
                imports.append(json.loads(archive.read('manifest.json')))
        return render(request, 'packages.html', {'jobs': jobs, 'imports': imports})

    @app.post('/packages/export')
    async def export(request: Request):
        data = await form(request)
        with closing(Register(settings)) as register:
            exchange.enqueue(register, UUID(data['analysis_id']), data['idempotency_key'])
        return RedirectResponse('/packages', status_code=303)

    @app.get('/packages/{job_id}/download')
    def download(request: Request, job_id: UUID):
        with closing(Register(settings, readonly=True)) as register:
            job = register.connection.execute('SELECT * FROM exchange_job WHERE id=?', (str(job_id),)).fetchone()
        if not job or job['status'] != 'ready':
            raise GateError('Studienpaket ist noch nicht bereit')
        path = settings.staging / 'packages' / (str(job_id) + '.zip')
        exchange.verify(path)
        with path.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != job['sha256']:
                raise GateError('Paketdatei nach Export verändert')
        return FileResponse(path, media_type='application/zip', filename='study-' + str(job_id) + '.zip')

    @app.post('/packages/import')
    async def upload(request: Request):
        if request.headers.get('origin') != str(request.base_url).rstrip('/') or request.headers.get('sec-fetch-site') in ('cross-site', 'none'):
            raise GateError('Import benötigt dieselbe lokale Herkunft')
        async def bounded_stream():
            size = 0
            async for chunk in request.stream():
                size += len(chunk)
                if size > exchange.MAX_ZIP + 65536:
                    raise GateError('Upload überschreitet 1 GiB')
                yield chunk
        data = await MultiPartParser(request.headers, bounded_stream(), max_files=1, max_fields=2).parse()
        try:
            csrf = data.get('csrf', '')
            if not isinstance(csrf, str) or not csrf or not hmac.compare_digest(csrf, request.cookies.get('research_csrf', '')):
                raise GateError('CSRF-Nachweis fehlt')
            if len(list(data.multi_items())) != len(data) or set(data) != {'csrf', 'archive'}:
                raise GateError('Import benötigt genau ein Archiv und CSRF')
            root = settings.staging / 'uploads'
            root.mkdir(exist_ok=True)
            path = root / (str(uuid4()) + '.zip')
            try:
                with path.open('xb') as target:
                    size = 0
                    while chunk := await data['archive'].read(1024 * 1024):
                        size += len(chunk)
                        if size > exchange.MAX_ZIP:
                            raise GateError('Upload überschreitet 1 GiB')
                        target.write(chunk)
                manifest = await run_in_threadpool(exchange.import_archive, settings, path)
            finally:
                path.unlink(missing_ok=True)  # Only this request's temporary upload.
        finally:
            await data.close()
        return RedirectResponse('/packages/imports/' + manifest['package_id'], status_code=303)

    @app.get('/packages/imports/{package_id}')
    def imported(request: Request, package_id: UUID):
        path = settings.staging / 'imports' / (str(package_id) + '.zip')
        manifest = exchange.verify(path)
        with zipfile.ZipFile(path) as archive:
            result = json.loads(archive.read('analysis/analysis.json'))
        return render(request, 'package.html', {'manifest': manifest, 'result': result,
            'compatible': manifest['source_binding'] == source_binding(),
            'recalculated': (settings.staging / 'derivations' / (str(package_id) + '.json')).exists()})

    @app.post('/packages/imports/{package_id}/recalculate')
    async def recalculate(request: Request, package_id: UUID):
        await form(request)
        path = settings.staging / 'imports' / (str(package_id) + '.zip')
        result = exchange.recalculate(path)
        root = settings.staging / 'derivations'
        content = canonical(result).encode()
        destination = root / (str(package_id) + '.json')
        if destination.exists():
            if destination.read_bytes() != content:
                raise GateError('Bestehende Ableitung weicht ab; Original bleibt erhalten')
        else:
            atomic_file(root, destination.name, content)
        return RedirectResponse('/packages/imports/' + str(package_id), status_code=303)

    @app.get('/packages/imports/{package_id}/outputs/{filename}')
    def imported_output(request: Request, package_id: UUID, filename: str):
        path = settings.staging / 'imports' / (str(package_id) + '.zip')
        manifest = exchange.verify(path)
        if not re.fullmatch(r'[A-Za-z0-9_-]+\.(csv|json|png|svg|pdf)', filename) or 'analysis/' + filename not in manifest['files']:
            raise GateError('Unbekannte Ausgabedatei')
        with zipfile.ZipFile(path) as archive:
            content = archive.read('analysis/' + filename)
        # Only signature-checked PNG is displayed inline; active archive formats stay downloads.
        if request.query_params.get('inline') == 'true' and filename.endswith('.png'):
            if not content.startswith(b'\x89PNG\r\n\x1a\n'):
                raise GateError('Ungültige PNG-Grafik')
            return Response(content, media_type='image/png', headers={'X-Content-Type-Options': 'nosniff'})
        # Never render arbitrary archived HTML or SVG as an active same-origin page.
        return Response(content, media_type='application/octet-stream',
                        headers={'Content-Disposition': 'attachment; filename="' + filename.replace('"', '') + '"'})
